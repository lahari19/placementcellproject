$(".year").hover(function(){

	$(".yearc").toggleClass("hide")
	$(".year").toggleClass("selected")
})

$(".course").hover(function(){

	$(".coursec").toggleClass("hide")
	$(".course").toggleClass("selected")
})

$(".sector").hover(function(){

	$(".sectorc").toggleClass("hide")
	$(".sector").toggleClass("selected")
})