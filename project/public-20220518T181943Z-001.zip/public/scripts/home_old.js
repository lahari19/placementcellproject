// console.log(document.documentElement.clientWidth);
// console.log(window.onscroll);
window.onscroll = function(){
  // // console.log(window.scrollY);
  // document.getElementById("fade").style.opacity=window.scrollY/200;
  // var value=1-window.scrollY/500;
  // if(value<.3){
  //   document.getElementById("fade-main").style.opacity=.3;
  // }
  // else{
  //   document.getElementById("fade-main").style.opacity=value;
  // }
  // // if (document.getElementById("fade").style.opacity>.7){
  // //   console.log("i am in");
  // //   document.getElementById("fade").style.color="white";
  // // }
  // // else{
  // //   document.getElementById("fade").style.color="black";
  // // }
}

